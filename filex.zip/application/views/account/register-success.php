<h1>
	شما ثبت نام شدید
       <?php echo anchor('account/', 'logout', 'title="logout"'); ?>
</h1>