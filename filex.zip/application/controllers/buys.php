<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Buys extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		if($this->account_object->is_login()===FALSE)
			redirect("account/");
		$this->load->model("license_object");
	}
	public function index()
	{
		
		
		$this->load->view("buys",array('buys'=>$this->license_object->get_buys($this->account_object->get_data('id'))));
	}
	public function view()
	{
		
		$this->load->view("buy_item",array('licenses'=>$this->license_object->get_buys_licenses($this->uri->segment(2))));
	}
	public function export()
	{
		$address=$this->config->item('cart_image');

		
		$image = imagecreatefromjpeg($address);

		$black = imagecolorallocate($image, 0, 0, 0);
		$font_path = 'yekan.ttf';
		$text = "This is a sunset!";

		imagettftext ( $image , 25,0 , 100 , 100, $black , $font_path , $text );

		imagestring ( $image ,5 ,100 , 100 , $text ,$black );
		imagejpeg($image,"output/output.jpg",100);
		echo "okey";
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */